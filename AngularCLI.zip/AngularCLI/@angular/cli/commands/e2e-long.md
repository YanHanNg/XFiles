Must be executed from within a workspace directory.
When a project name is not supplied, it will execute for all projects.