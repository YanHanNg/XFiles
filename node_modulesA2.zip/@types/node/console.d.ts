declare module 'node:console' {
    export = console;
}

declare module 'console' {
    export = console;
}
