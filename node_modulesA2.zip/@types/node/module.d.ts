declare module 'node:module' {
    export = NodeJS.Module;
}

declare module 'module' {
    export = NodeJS.Module;
}
