# Installation
> `npm install --save @types/selenium-webdriver`

# Summary
This package contains type definitions for Selenium WebDriverJS (https://github.com/SeleniumHQ/selenium/tree/master/javascript/node/selenium-webdriver).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/selenium-webdriver/v3.

### Additional Details
 * Last updated: Wed, 12 Feb 2020 21:27:52 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bill Armstrong (https://github.com/BillArmstrong), Yuki Kokubun (https://github.com/Kuniwak), Craig Nishina (https://github.com/cnishina), Simon Gellis (https://github.com/SupernaviX), Ben Dixon (https://github.com/bendxn), and Ziyu (https://github.com/oddui).
