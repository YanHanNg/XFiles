import { Rule } from '@angular-devkit/schematics';
import { Schema as ComponentOptions } from './schema';
export default function (options: ComponentOptions): Rule;
