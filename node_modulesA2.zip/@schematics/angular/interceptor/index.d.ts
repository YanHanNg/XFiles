import { Rule } from '@angular-devkit/schematics';
import { Schema as InterceptorOptions } from './schema';
export default function (options: InterceptorOptions): Rule;
