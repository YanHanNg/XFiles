import { Tree } from '@angular-devkit/schematics';
export declare function isIvyEnabled(tree: Tree, tsConfigPath: string): boolean;
export declare function forwardSlashPath(path: string): string;
