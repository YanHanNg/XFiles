import { Rule } from '@angular-devkit/schematics';
export declare const ANY_COMPONENT_STYLE_BUDGET: {
    type: string;
    maximumWarning: string;
};
export declare function updateWorkspaceConfig(): Rule;
