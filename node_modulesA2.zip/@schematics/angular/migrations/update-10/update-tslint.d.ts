import { Rule } from '@angular-devkit/schematics';
export declare const TSLINT_VERSION = "~6.1.0";
export default function (): Rule;
